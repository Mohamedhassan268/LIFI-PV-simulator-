# Paper Validation Files — Complete Index

## Overview

You have **9 files** covering **6 papers**. Some papers have a single monolithic file, others are split across preset/simulator/plots modules. All are standalone Python scripts that implement physics models and generate validation plots against published experimental results.

Your existing project (not included here but found via project knowledge) has a **modular simulator architecture** with:
- `simulator/transmitter.py`, `simulator/channel.py`, `simulator/receiver.py`, `simulator/demodulator.py`, `simulator/noise.py`
- `config/presets.py` (already has some paper presets started)
- `papers/` folder (with integrated validation scripts that import from `simulator/`)
- `main.py` (7-layer simulation pipeline)
- `utils/output_manager.py`

The 9 files here are the **standalone** validation scripts — they do NOT yet import from the unified simulator. They each re-implement physics from scratch.

---

## Paper-by-Paper Breakdown

### 1. Correa Morales et al. (2025) — Greenhouse VLC
**Files:** `correa_2025_physics.py` (1,190 lines)
**Paper:** "Experimental design and performance evaluation of a solar panel-based VLC system for greenhouse applications" — *Scientific Reports, 2025*

| Aspect | Details |
|---|---|
| **Receiver** | Solar panel (66 cm², poly-Si, R_load=220Ω, C_eq=50nF) |
| **Modulation** | PWM-ASK (10 Hz PWM + 10 kHz ASK carrier) |
| **Key physics** | Lambertian path loss, Beer-Lambert humidity attenuation, RC low-pass, comprehensive noise model (shot + thermal + ambient + ADC + processing) |
| **Validation targets** | Fig 6 (received power vs distance), Fig 7 (BER vs distance at 6 humidity levels), bandwidth ≈14 kHz |
| **Unique features** | Humidity sweep (30–80% RH), SDM detection algorithm modeling, greenhouse ambient light |
| **Structure** | Single monolithic file. All physics functions + plotting + `run_validation()` entry point |

**Key physics to extract:** `humidity_to_alpha()`, `compute_noise_std()` (6-source noise model), PWM-ASK BER model

---

### 2. González-Uriarte et al. (2024) — Low-Cost VLC Receiver
**Files:** `gonzalez_validation.py` (797 lines)
**Paper:** "Design and Implementation of a Low-Cost VLC Photovoltaic Panel-Based Receiver with off-the-Shelf Components" — *IEEE LATINCOM 2024*

| Aspect | Details |
|---|---|
| **Receiver** | Poly-Si PV panel (66 cm², C_j=14.5nF, R_sh=200kΩ) with 220Ω load |
| **Modulation** | OOK-Manchester at 4.8 kBd |
| **Key physics** | PV panel AC model (R_sh ∥ C_j ∥ R_load), 100 Hz Twin-T notch filter, amplifier (G=165×), data slicer |
| **Validation targets** | Fig 2 (bandwidth vs R_load), Fig 3 (voltage vs R_load), time-domain waveforms, BER vs interference |
| **Unique features** | Full receiver chain simulation (notch → amp → slicer), Manchester encoding/decoding |
| **Structure** | Two classes (`PVPanelACModel`, `ReceiverChain`) + simulation functions + plotting |

**Key physics to extract:** `PVPanelACModel` (R_sh ∥ C_j bandwidth model), `ReceiverChain` (notch + amp + slicer pipeline), Manchester codec

---

### 3. Kadirvelu et al. (2021) — Simultaneous Data + Power
**Files:** `kadirvelu_v2.py` (1,029 lines)
**Paper:** "A Circuit for Simultaneous Reception of Data and Power Using a Solar Cell" — *IEEE Trans. Green Commun. Netw., Vol. 5, No. 4, Dec 2021*

| Aspect | Details |
|---|---|
| **Receiver** | GaAs solar cell module (9 cm², R_λ=0.457 A/W, C_j=798nF, R_sh=138.8kΩ) |
| **Modulation** | OOK with DC-DC converter switching at 50–200 kHz |
| **Key physics** | Solar cell small-signal model (Z_d, Z_load impedances), current-sense transfer function, INA+BPF receiver chain, DC-DC converter efficiency model |
| **Validation targets** | Fig 12 (channel gain), Fig 13 (transfer functions), Fig 14 (BPF response), Fig 17 (BER vs modulation depth), Fig 18 (V_out vs modulation), Fig 19 (power vs bitrate tradeoff) |
| **Unique features** | SLIPT tradeoff modeling (harvested power vs data rate), switching frequency analysis, modulation depth sweep |
| **Structure** | `PaperParams` dataclass + physics functions + BER computation + figure generation |

**Key physics to extract:** `H_isc()`, `H_sense()` (impedance-based transfer functions), `compute_BER()` (switching-noise-aware), DC-DC efficiency model, power-bitrate tradeoff (Eq. 20)

---

### 4. Oliveira et al. (2024) — Reconfigurable MIMO SLIPT
**Files:** `oliveira_2024_preset.py` (261 lines) + `oliveira_2024_simulator.py` (942 lines) + `oliveira_2024_plots.py` (691 lines) = **3 files, ~1,894 lines total**
**Paper:** "Reconfigurable MIMO-based self-powered battery-less light communication system" — *Light: Science & Applications, 2024*

| Aspect | Details |
|---|---|
| **Receiver** | 3×3 PD array (large 1cm² or small 7.7mm²), mode switching (photoconductive/photovoltaic) |
| **Modulation** | OFDM with adaptive M-QAM (up to 64-QAM), 500 subcarriers |
| **Key physics** | OFDM bit/power loading, quadrant-based beam tracking, energy harvesting model, wavelength-based SLIPT detection |
| **Validation targets** | Fig 3c (SNR/BER/SE per subcarrier), Fig 3d (QAM constellations), Fig 4c (beam tracking), Fig 5 (energy harvesting table), data rates (SISO 25.7 Mbps, MIMO 102.8 Mbps) |
| **Unique features** | Reconfigurable PD array, 10 quadrant configurations, supercapacitor charging model, color detection |
| **Structure** | **Best structured** — clean separation of preset/simulator/plots. `ReconfigurablePDArray` class, `OFDMEngine`, `BeamTracker`, `EnergyHarvester` |

**Key physics to extract:** `ReconfigurablePDArray` (mode switching model), `OFDMEngine` (adaptive loading), `BeamTracker`, energy harvesting interpolation model, supercap charging dynamics

---

### 5. Sarwar et al. (2017) — OFDM Solar Panel VLC
**Files:** `validate_sarwar_2017.py` (291 lines)
**Paper:** "Visible Light Communication Using a Solar-Panel Receiver" — *ICOCN 2017*

| Aspect | Details |
|---|---|
| **Receiver** | Solar panel (7.5 cm², C_j=500pF, R_sh=10kΩ) |
| **Modulation** | OFDM 16-QAM, 80 subcarriers, 5 MHz bandwidth |
| **Key physics** | Solar panel RC channel response, OFDM TX/RX chain with ZF equalization, per-subcarrier BER/EVM |
| **Validation targets** | 15.03 Mbps data rate, BER=1.6883×10⁻³, Fig 4 (BER per subcarrier), Fig 5 (EVM), Fig 6 (spectrum), Fig 7 (constellation) |
| **Unique features** | Full OFDM simulation with Gray-coded 16-QAM, per-subcarrier analysis |
| **Structure** | Single class `Sarwar2017Validator` with all methods. Compact and clean |

**Key physics to extract:** OFDM simulation chain, 16-QAM mod/demod with Gray coding, per-subcarrier SNR model, channel response from panel RC

---

### 6. Xu et al. (2024) — Sunlight-Duo
**Files:** `xu_2024_simulator.py` (987 lines) + `xu_2024_plots.py` (1,085 lines) = **2 files, ~2,072 lines**
*Note: Both import from `xu_2024_preset.py` which is NOT in the project files — it's a missing dependency.*
**Paper:** "Sunlight-Duo: Exploiting Sunlight for Simultaneous Energy Harvesting & Communication" — *EWSN 2024*

| Aspect | Details |
|---|---|
| **Receiver** | 16-cell reconfigurable solar array (2s-8p / 4s-4p / 8s-2p switching) |
| **Modulation** | BFSK via liquid crystal (LC) shutter — passive modulation of sunlight |
| **Key physics** | Reconfigurable array (series/parallel switching), LC shutter dynamics (rise/fall time), BQ25570 CV-MPPT charger, supercap cold-start charging |
| **Validation targets** | Fig 4 (charger comparison), Fig 5/6 (Pareto frontiers), Fig 9 (BER comparison), Fig 10d/12b (PSR vs distance), Fig 12c (PSR vs data rate), Fig 13 (link quality) |
| **Unique features** | Passive sunlight modulation (no LED TX!), dynamic reconfiguration controller, Pareto frontier analysis (charging vs communication) |
| **Structure** | Well-structured with classes: `ReconfigurableSolarArray`, `LCShutter`, `BFSKModem`, `MPPTCharger`, `DynamicReconfigController`, `SunlightDuoSimulator` |

**Key physics to extract:** `ReconfigurableSolarArray` (Voc/Isc scaling), `LCShutter` (rise/fall dynamics), `MPPTCharger` (CV algorithm + supercap model), `DynamicReconfigController`, Pareto analysis

---

## Summary Matrix

| Paper | Year | Files | Lines | Receiver Type | Modulation | Data Rate | SLIPT? | Key Innovation |
|---|---|---|---|---|---|---|---|---|
| Correa | 2025 | 1 | 1,190 | Solar panel (poly-Si) | PWM-ASK | ~10 bps | No | Humidity effects in greenhouse |
| González | 2024 | 1 | 797 | PV panel (poly-Si) | OOK-Manchester | 4.8 kbps | No | Low-cost notch+amp+slicer chain |
| Kadirvelu | 2021 | 1 | 1,029 | GaAs solar cell | OOK + DC-DC | 1–40 kbps | **Yes** | Simultaneous data+power circuit |
| Oliveira | 2024 | 3 | 1,894 | 3×3 PD array | OFDM M-QAM | 25.7–102.8 Mbps | **Yes** | Reconfigurable MIMO PD array |
| Sarwar | 2017 | 1 | 291 | Solar panel | OFDM 16-QAM | 15.03 Mbps | No | First OFDM solar panel demo |
| Xu | 2024 | 2 | 2,072 | 16-cell solar array | BFSK (LC shutter) | ~100 bps | **Yes** | Passive sunlight modulation |

## Missing Dependencies

- **`xu_2024_preset.py`** — imported by both Xu files but NOT present in the project files. Contains `SOLAR_CELL_SPECS`, `CELL_CONFIGURATIONS`, `CHARGER_SPECS`, `PRECHARGE_PARETO_DATA`, etc. This is a blocker for running the Xu validation.

## Integration Readiness

| Paper | Self-Contained? | Uses Project Imports? | Integration Effort |
|---|---|---|---|
| Correa | ✅ Yes | ❌ No (all inline) | Medium — extract physics into `simulator/` modules |
| González | ✅ Yes | ❌ No (all inline) | Medium — `PVPanelACModel` and `ReceiverChain` map well to existing `receiver.py` |
| Kadirvelu | ✅ Yes | ❌ No (all inline) | Medium — impedance-based model is unique, needs new module |
| Oliveira | ⚠️ Mostly (preset inline in plots) | ❌ No | Low — already well-structured, closest to project patterns |
| Sarwar | ✅ Yes | ❌ No (all inline) | Low — compact, clean class structure |
| Xu | ❌ Missing preset file | ❌ No | High — need to reconstruct `xu_2024_preset.py` |
