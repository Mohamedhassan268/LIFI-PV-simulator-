# Phase 1 Audit: Correa + González Gap Analysis

## Audit Complete — Here's What I Found

### 1. `simulator/channel.py` — Humidity Model

**Status: ✅ ALREADY INTEGRATED**

The channel already has `_compute_alpha(humidity)` and Beer-Lambert attenuation.
However, there's a **divergence** between the two implementations:

| Aspect | Standalone (correa_2025_physics.py) | Project (channel.py) |
|---|---|---|
| Formula | `α = 0.3 + 4.0 × (RH - 0.3)^1.5` | `α = 0.5 + 9.0 × (RH - 0.3) × 1.5` |
| At 30% RH | 0.3 m⁻¹ | 0.5 m⁻¹ |
| At 80% RH | 3.12 m⁻¹ | 7.25 m⁻¹ |
| Exponent | Power law `^1.5` | **Linear** `× 1.5` (comment says "FIXED: was ** 1.5") |
| Humidity layer depth | Not used (full distance) | Caps at 0.6m |

**Issue:** The project version changed the exponentiation to multiplication (a "fix" comment says it was intentional), but the standalone version's `^1.5` power law is physically correct — aerosol scattering grows nonlinearly. The project version also caps the humidity attenuation at `humidity_layer_depth=0.6m`, which the standalone doesn't.

**Action needed:** Verify which alpha formula reproduces Correa Fig 6 better. The standalone version was specifically tuned to match the paper, so it's likely more accurate.

---

### 2. `simulator/noise.py` — Noise Sources

**Status: ⚠️ MISSING 2 OF 6 SOURCES**

| Noise Source | Standalone | Project `noise.py` |
|---|---|---|
| 1. Shot noise | ✅ | ✅ |
| 2. Thermal noise | ✅ | ✅ |
| 3. Ambient light shot noise | ✅ | ✅ |
| 4. Amplifier noise | ✅ | ✅ |
| 5. ADC quantization noise | ✅ | ❌ Missing |
| 6. Processing/threshold noise | ✅ | ❌ Missing |

The project's `NoiseModel` has 4 sources. The standalone Correa file has 6.
Sources 5-6 are crucial for Correa because the solar panel has very high SNR from pure noise (>100 dB), but BER is dominated by ADC quantization and SDM processing errors.

**Action needed:** Add `adc_noise_variance()` and `processing_noise_variance()` methods to `NoiseModel`.

---

### 3. `simulator/demodulator.py` — BER Prediction

**Status: ⚠️ OOK ONLY — NO PWM-ASK**

The project has:
- `predict_ber_ook(snr_linear)` — simple Q-function
- `utils/ber.py` — OOK, BPSK, M-QAM BER formulas

But Correa uses PWM-ASK modulation, which has a **completely different BER model** based on:
- Carrier sync errors
- Pulse width measurement jitter
- SDM template matching errors
- Threshold hysteresis

The standalone file has `compute_ber_pwm_ask()` — a complex ~80-line function.

**Action needed:** The standalone already has this. Either:
(a) Add `predict_ber_pwm_ask()` to `utils/ber.py`, or
(b) Keep it in the `papers/correa_2025.py` validation script since it's paper-specific

I recommend (b) since PWM-ASK is only used by this one paper.

---

### 4. `simulator/receiver.py` — Bandwidth with R_sh

**Status: ✅ ALREADY CORRECT**

`PVReceiver.calculate_bandwidth()` already uses `R_eq = R_sh ∥ R_load`:
```python
R_eq = (self.R_sh * R_load) / (self.R_sh + R_load)
f_3db = 1.0 / (2 * np.pi * R_eq * self.C_j)
```

This matches both González's `PVPanelACModel` and Correa's model. No change needed.

---

### 5. `simulator/modulation.py` — PWM-ASK Modulator

**Status: ✅ ALREADY EXISTS**

The project already has `PWMASKModulator` and `PWMASKDemodulator` classes. No change needed.

---

### 6. `papers/correa_2025.py` (integrated version)

**Status: ⚠️ EXISTS BUT INCOMPLETE**

There's already a `papers/correa_2025.py` that imports from `simulator/`. From the project knowledge search, it imports:
- `PVReceiver`, `Transmitter`, `OpticalChannel`, `NoiseModel`
- `predict_ber_ook`, `compute_eb_n0`
- `get_paper_output_dir`

But it uses `predict_ber_ook` instead of the PWM-ASK BER model, and it doesn't have the complete figure generation (Fig 6, Fig 7) from the standalone.

**Action needed:** Upgrade `papers/correa_2025.py` to:
1. Use the correct humidity alpha formula
2. Use the full 6-source noise model
3. Implement PWM-ASK BER (can be inline since paper-specific)
4. Generate Fig 6 + Fig 7 + frequency response

---

### 7. González Status

The `papers/gonzalez_2024.py` in the project already imports from simulator. The standalone `gonzalez_validation.py` has:
- `PVPanelACModel` → maps to `PVReceiver` (bandwidth already correct ✅)
- `ReceiverChain` (notch + amp + slicer) → `receiver.py` already has notch, INA, BPF ✅
- Manchester encoding → standalone implements it, project may not have it

**Action needed for González:** Mostly about verification — run the integrated version and compare outputs. Manchester codec may need adding to modulation.py.

---

## Summary: What Actually Needs Changing

### Must Fix (blocks Correa validation):
1. **`simulator/noise.py`** — Add ADC + processing noise sources
2. **`simulator/channel.py`** — Verify/fix humidity alpha formula (standalone `^1.5` vs project `×1.5`)
3. **`papers/correa_2025.py`** — Rewrite to use full standalone physics, generate Fig 6+7

### Already Working (no changes needed):
- `receiver.py` bandwidth calculation (R_sh ∥ R_load) ✅
- `modulation.py` PWM-ASK modulator ✅  
- `utils/ber.py` OOK/M-QAM formulas ✅
- `config/presets.py` Correa preset ✅

### Defer (González, not blocking):
- Manchester encoder/decoder
- González figure generation verification
