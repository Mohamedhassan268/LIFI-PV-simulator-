# Integration Plan: Standalone Validations → Project Simulator

## What You Already Have (Project)

Your project already has a solid layered architecture:

```
simulator/
  transmitter.py    → OOK, PWM-ASK, passive FSK modulation
  channel.py        → Lambertian, Beer-Lambert, MIMO H-matrix, multipath
  receiver.py       → PVReceiver, MIMOPVReceiver, ReconfigurablePVArray
                       + full receiver chains (current-sense, INA, BPF, notch, TIA)
  demodulator.py    → BER prediction, Eb/N0
  noise.py          → Noise model

config/
  presets.py         → PaperPreset class + Kadirvelu, Correa, Sarwar, Xu presets

papers/
  __init__.py
  correa_2025.py     → Already imports from simulator/, partially integrated
  gonzalez_2024.py   → Already imports from simulator/, partially integrated
  xu_2024.py         → Already imports from simulator/, partially integrated

utils/
  output_manager.py  → Test folder management
  paper_configs.py   → Paper config registry
```

**Key insight:** You already have `papers/` versions of Correa, González, and Xu that import from `simulator/`. Those are the *integrated* versions. The 9 standalone files in the project are the *original standalone* scripts written before integration — they contain the raw physics knowledge that needs to be migrated into the simulator modules.

---

## My Recommendation: Knowledge Extraction, Not File Migration

The goal is NOT to copy these files into the project. The goal is to **mine them for physics and logic that your simulator modules are still missing**, then upgrade the simulator, then make sure each `papers/` validation script works against the upgraded simulator and reproduces the paper results.

### Phase 1: Audit What's Missing (Do First)

Compare each standalone file against what `simulator/` already supports. The gaps are:

| Standalone Physics | Simulator Status | Action Needed |
|---|---|---|
| **Correa** humidity→alpha (Beer-Lambert) | `channel.py` has `attenuation_alpha` but no humidity model | Add `humidity_to_alpha()` to `channel.py` |
| **Correa** 6-source noise model (shot+thermal+ambient+amp+ADC+processing) | `noise.py` exists but unclear if it has all 6 | Audit `noise.py`, add missing sources |
| **Correa** PWM-ASK BER with SDM threshold | `demodulator.py` has `predict_ber_ook` only | Add `predict_ber_pwm_ask()` to demodulator |
| **González** R_sh ∥ C_j ∥ R_load bandwidth model | `receiver.py` has RC model but unclear if R_sh is included | Verify PVReceiver handles shunt resistance in bandwidth calc |
| **González** Notch + Amp + Slicer chain | `receiver.py` already has notch + INA + BPF methods | Likely already covered — just verify |
| **González** Manchester encoding | `transmitter.py` / `demodulator.py` | Add Manchester codec if missing |
| **Kadirvelu** Impedance-based transfer functions (H_isc, H_sense) | `receiver.py` has current-sense chain | Compare approaches — Kadirvelu's is more rigorous |
| **Kadirvelu** DC-DC converter efficiency model | Not in simulator | Add `energy/dcdc.py` or extend receiver |
| **Kadirvelu** Power-bitrate tradeoff (Eq. 20) | Not in simulator | Add to energy harvesting module |
| **Oliveira** OFDM engine with adaptive M-QAM loading | `demodulator.py` only has OOK/basic | Add `modulation/ofdm.py` module |
| **Oliveira** Beam tracking (quadrant scan) | Not in simulator | Add to receiver or create `tracking.py` |
| **Oliveira** Supercapacitor charging dynamics | Not in simulator | Add `energy/supercap.py` |
| **Sarwar** Full OFDM simulation chain | Same gap as Oliveira | Same OFDM module covers both |
| **Sarwar** Per-subcarrier BER/EVM analysis | Not in demodulator | Add to OFDM module |
| **Xu** LC shutter dynamics (rise/fall time) | `transmitter.py` has `modulate_fsk_passive` | Already partially there — verify rise/fall model |
| **Xu** Reconfigurable array (series/parallel) | `receiver.py` has `ReconfigurablePVArray` | Already there — verify Voc/Isc scaling matches |
| **Xu** MPPT charger (CV algorithm) | Not in simulator | Add `energy/mppt.py` |
| **Xu** Dynamic reconfiguration controller | Not in simulator | Add `control/reconfiguration.py` |

### Phase 2: Upgrade Simulator Modules (Main Work)

Based on the audit, I'd prioritize in this order:

**Priority 1 — Small wins, many papers benefit:**
1. `channel.py` — Add humidity-dependent attenuation model (from Correa)
2. `noise.py` — Ensure all 6 noise sources are available (from Correa)
3. `demodulator.py` — Add PWM-ASK BER prediction (from Correa)
4. Verify `receiver.py` bandwidth calculation includes R_sh (from González)

**Priority 2 — OFDM support (unlocks Sarwar + Oliveira):**
5. Create `simulator/ofdm.py` — OFDM engine with:
   - FFT/IFFT, cyclic prefix
   - M-QAM modulation/demodulation (4/16/64-QAM)
   - Adaptive bit loading based on per-subcarrier SNR
   - Per-subcarrier BER/EVM computation
   - ZF and MMSE equalization
   (Extract from Sarwar's clean implementation, extend with Oliveira's adaptive loading)

**Priority 3 — Energy harvesting subsystem (unlocks Kadirvelu + Xu):**
6. Create `simulator/energy.py` (or `energy/` subpackage) with:
   - DC-DC converter model with frequency-dependent efficiency (from Kadirvelu)
   - Supercapacitor charging dynamics (from Oliveira + Xu)
   - MPPT algorithms: P&O and CV (from Xu)
   - Power-bitrate tradeoff computation (from Kadirvelu Eq. 20)

**Priority 4 — Advanced features:**
7. Beam tracking / quadrant scanning (from Oliveira)
8. Dynamic reconfiguration controller (from Xu)
9. Manchester codec (from González)

### Phase 3: Rewrite Paper Validation Scripts

Once the simulator is upgraded, rewrite each `papers/` script to:
- Import ONLY from `simulator/`, `config/presets`, and `utils/`
- Use the preset for locked parameters
- Call simulator modules for physics
- Only contain paper-specific orchestration and plotting
- Validate against the targets in `utils/paper_configs.py`

---

## Recommended Execution Order

```
Week 1: Phase 1 (Audit) + Priority 1 (channel, noise, demodulator fixes)
         → Validates: Correa, González (simple papers, quick wins)

Week 2: Priority 2 (OFDM module)
         → Validates: Sarwar, Oliveira SISO mode

Week 3: Priority 3 (Energy harvesting)
         → Validates: Kadirvelu, Xu charging, Oliveira harvesting

Week 4: Priority 4 + Phase 3 (rewrite all papers/ scripts)
         → Full validation suite running against unified simulator
```

## How I'd Suggest We Work Together

Option A — **One paper at a time, end-to-end:** Pick a paper, audit its standalone file vs simulator, upgrade simulator modules as needed, rewrite the papers/ script, verify it reproduces results. Move to next paper. This is the safest approach.

Option B — **Module-first:** Upgrade simulator modules in priority order (channel → noise → demodulator → OFDM → energy), then batch-rewrite all papers/ scripts. Faster but riskier — you don't validate until the end.

Option C — **Hybrid:** Do Priority 1 fixes first (small, surgical), immediately validate Correa + González. Then do OFDM module and validate Sarwar + Oliveira. Then energy module and validate Kadirvelu + Xu.

**I recommend Option C.** It gives you working validations at every step, and the OFDM and energy modules are the two biggest architectural additions that will define the structure.

---

## One Blocker to Resolve

`xu_2024_preset.py` is missing from the project files. The two Xu standalone files both import from it. You either need to:
1. Find it in your repo and add it to the project, or
2. We reconstruct it from what the simulator and plots files expect to import

This blocks any Xu work until resolved.

---

## What to Do Right Now

Tell me which approach you prefer (A, B, or C), and which paper you want to start with. If you go with C, I'd start by:

1. Auditing `simulator/noise.py` and `simulator/channel.py` against Correa's standalone
2. Making the surgical fixes
3. Getting `papers/correa_2025.py` to reproduce Fig 6 + Fig 7

That would give us a clean template for how every subsequent paper integration should work.
