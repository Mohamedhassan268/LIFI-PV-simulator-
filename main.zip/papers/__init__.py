"""
Validation Papers Module

Each file in this directory represents a specific research paper validation.
They must expose a `run_validation()` function.
"""
